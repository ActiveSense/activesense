# GENEAread
GENEAread package development for Activinsights
